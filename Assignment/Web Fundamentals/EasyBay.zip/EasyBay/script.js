// Function to remove the element represented by the parameter
function removeElement(element){
    element.remove();
}

// Function on Cart Click
function cartHandler(){
    alert('Your Cart is empty!');
}

function showPic1(){
    var pic = document.getElementById("pic");
    pic.src = "images/succulents-1.jpg";
}

function showPic2(){
    var pic = document.getElementById("pic");
    pic.src = "images/succulents-2.jpg";
}

